<template>
  <services-banner/>
  <service-catalogue />
  <find-out-more />
  <spectrum-section />
  <test-us />
  <questions-banner />
  <qualities title="Discover the XCL Labs Difference" />
</template>


<script setup>

import ServicesBanner from "@/Sections/ServicesSection/ServicesBanner.vue";
import ServiceCatalogue from "@/Sections/ServicesSection/ServiceCatalogue.vue";
import FindOutMore from "@/Sections/ServicesSection/FindOutMore.vue";
import SpectrumSection from "@/Sections/ServicesSection/SpectrumSection.vue";
import TestUs from "@/Sections/ServicesSection/TestUs.vue";
import QuestionsBanner from "@/Sections/SharedSections/QuestionsBanner.vue";
import Qualities from "@/Sections/SharedSections/Qualities.vue";
</script>
