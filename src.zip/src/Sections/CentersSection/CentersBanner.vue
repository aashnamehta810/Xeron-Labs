<template>
    <div class="nav-width-parent-container">
        <div class="mobile-nav-child-even bg bg-cover bg-center w-full lg:h-[534px] rounded-[20px] lg:px-[83px] pt-12
        pb-24 lg:pt-[43px] lg:pb- flex flex-col text-white">
            <p class="text-[14px] tracking-[3.08px] font-medium">PATIENTS SERVICE CENTERS</p>
            <p class="h1 lg:text-[60px]  -tracking-[1.2px] font-naga mt-[81px] lg:w-8/12">
                Convenient and accessible laboratory services right in your area.
            </p>
        </div>
    </div>
</template>

<script setup>
</script>


<style scoped>
.bg {
    background-image: url("/imgs/careers/smiles.png");
}
</style>


