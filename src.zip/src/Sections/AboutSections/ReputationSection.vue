<template>
  <div class="hero-width-parent-container lg:mt-[77px]">
    <div class="mobile-nav-child-even lg:lg-child-container lg:flex-row items-center gap-[50px] 3xl:gap-[177px]">
      <div class="flex flex-col gap-4 px-2 lg:px-0">
        <p class="h2">
          For the past two decades, Xeron has been at the forefront of leadership in the testing industry.
        </p>
        <p class="base">
          We have built a trusted reputation as a reliable laboratory that utilizes the latest technological
          advancements available.
        </p>
        <p class="base">Our extensive knowledge and experience enable us to provide more accurate results,
          making us the preferred laboratory for physicians and patients throughout New York.</p>
      </div>
      <img src="/imgs/about/microscope.png" alt="">
    </div>
    <hr class="lg:hidden my-12">
  </div>
</template>

<script setup>
</script>
