<template>
  <div class="nav-width-parent-container mt-[89px]">
    <div
        class="bg-[#DDE1EE]/[0.35] rounded-[20px] w-full flex flex-col lg:flex-row items-center mobile-nav-child-even
         lg:px-[53px] gap-8 lg:gap-[100px] 3xl:gap-[162px] lg:h-[496px] py-16 lg:py-0">
      <img
          class="order-2 lg:order-1"
          src="/imgs/clientele/laptop.png"
          alt="">
      <div class="flex flex-col w-full gap-6 px-6">
        <div class="text-2xl  font-naga  text-night lg:h2 relative">
          Workplace Testing / Employee Screening
          <div
              class="flex absolute top-0 -left-4  lg:top-1/2 lg:-translate-y-1/2 lg:-left-[30px] w-0 h-full lg:h-[65px]
              border-[2px] lg:border-[3px] border-dark-blue" />
        </div>
        <p class="base">
          Thorough pre-employment screening and testing services for employers.
        </p>
      </div>
    </div>
  </div>

  <hr class="my-20 lg:hidden">
</template>

<script setup>
</script>

<style scoped>

</style>