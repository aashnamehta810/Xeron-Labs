<template>
  <hero-section/>
  <services-section/>
  <!-- <toxicology-section/> -->
  <about-us-section />
  <whom-we-serve-section />
  <locations-section />
  <insurance-section />
  <professionals-section />
  <licenses-certification-section />
  <questions-banner />
  <qualities title="Discover the XCL Labs Difference"/>
</template>

<script setup>

import HeroSection from "@/Sections/HomeSections/HeroSection.vue";
import ServicesSection from "@/Sections/HomeSections/ServicesSection.vue";
// import ToxicologySection from "@/Sections/HomeSections/ToxicologySection.vue";
import AboutUsSection from "@/Sections/HomeSections/AboutUsSection.vue";
import WhomWeServeSection from "@/Sections/HomeSections/WhomWeServeSection.vue";
import LocationsSection from "@/Sections/HomeSections/LocationsSection.vue";
import InsuranceSection from "@/Sections/HomeSections/InsuranceSection.vue";
import ProfessionalsSection from "@/Sections/HomeSections/ProfessionalsSection.vue";
import LicensesCertificationSection from "@/Sections/HomeSections/LicensesCertificationSection.vue";
import QuestionsBanner from "@/Sections/SharedSections/QuestionsBanner.vue";
import Qualities from "@/Sections/SharedSections/Qualities.vue";
</script>
