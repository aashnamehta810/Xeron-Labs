export const services = [
  {
    name: "General Testing",
    img: "/imgs/home-service/medicare-img1.svg",
    link: "general-testing",
  },
  {
    name: "Andrology",
    img: "/imgs/home-service/medicare-img2.svg",
    link: "andrology",
  },
  {
    name: "Cytology",
    img: "/imgs/home-service/medicare-img3.svg",
    link: "cytology",
  },
  {
    name: "Chemistry",
    img: "/imgs/home-service/medicare-img4.svg",
    link: "chemistry",
  },
  {
    name: "Hematology",
    img: "/imgs/home-service/medicare-img5.svg",
    link: "hematology",
  },
  {
    name: "Molecular Virology",
    img: "/imgs/home-service/medicare-img6.svg",
    link: "molecular-virology",
  },
  {
    name: "Endocrinology",
    img: "/imgs/home-service/medicare-img7.svg",
    link: "endocrinology",
  },
  {
    name: "Serology",
    img: "/imgs/home-service/medicare-img8.svg",
    link: "serology",
  },
  {
    name: "Lead",
    img: "/imgs/home-service/medicare-img9.svg",
    link: "lead",
  },
  {
    name: "Drug Screening",
    img: "/imgs/home-service/medicare-img10.svg",
    link: "drug-screening",
  },
];
