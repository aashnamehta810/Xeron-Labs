<template>
  <careers-banner />
  <application-form />
  <questions-banner />
  <qualities title="Discover the XCL Labs Difference" />
</template>

<script setup>
import CareersBanner from "@/Sections/CareersSection/CareersBanner.vue";
import ApplicationForm from "@/Sections/CareersSection/ApplicationForm.vue";
import QuestionsBanner from "@/Sections/SharedSections/QuestionsBanner.vue";
import Qualities from "@/Sections/SharedSections/Qualities.vue";
</script>
