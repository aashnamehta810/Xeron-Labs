<template>
  <div
    class="nav-width-parent-container grid grid-cols-1 lg:grid-cols-2 gap-y-12 lg:gap-y-40 mt-[102px]"
  >
    <img
      alt=""
      class="bg-blue-gradient bg-cover rounded-[20px] order-1"
      src="/imgs/about/test_tube.png"
    />
    <div
      class="flex flex-col w-full gap-6 mobile-nav-child-even lg:pl-[89px] order-2"
    >
      <p class="tracking-[3.08px] text-dark-blue text-[14px] font-bold">
        OUR CULTURE
      </p>
      <p class="h2">Better people providing better results.</p>
      <p class="base">
        As a team of highly skilled and knowledgeable professionals, we are
        devoted to offering seamless testing solutions. Whether you are a doctor
        searching for results for your patient, or a client looking for
        trustworthy and reliable test results, we are dedicated to serving
        everyone with the utmost compassion, professionalism, and attention to
        detail.
      </p>
      <p class="base">
        Our goal is to provide top-quality services that meet the unique needs
        of each individual we serve.
      </p>
    </div>

    <!-- <div
        class="flex flex-col gap-12 lg:gap-[55px] w-full self-center justify-center mobile-nav-child-even lg:pr-[89px]
        lg:pl-[65px] order-4 lg:order-3">
      <p class="tracking-[3.08px] text-dark-blue text-[14px] font-bold lg:whitespace-nowrap">
        LICENSES, CERTIFICATION & ACCREDITATION
      </p>
      <p class="h2">Setting the Standard for excellence and trusted by leading physicians.</p>
      <p class="base">
        XCL is licensed by the New York State Department of Health
      </p>
      <img
          alt=""
          class="-mt-20 lg:-mt-[165px]"
          src="/imgs/about/New-York-2.png">
    </div>
    <img alt=""
         class="bg-blue-gradient bg-no-repeat bg-cover rounded-[20px] order-3 lg:order-4"
         src="/imgs/about/city.png"> -->
  </div>
</template>

<script setup></script>
