<template>
  <clientele-banner />
  <team-section />
  <workspace-testing />
  <about-us />
  <qualities title="Discover the XCL Labs Difference" />
</template>

<script setup>
import ClienteleBanner from "@/Sections/ClienteleSections/ClienteleBanner.vue";
import TeamSection from "@/Sections/ClienteleSections/TeamSection.vue";
import WorkspaceTesting from "@/Sections/ClienteleSections/WorkspaceTesting.vue";
import AboutUs from "@/Sections/ClienteleSections/AboutUs.vue";
import Qualities from "@/Sections/SharedSections/Qualities.vue";

</script>

