<template>
  <div class="flex flex-col nav-width-parent-container lg:nav-child lg:pt-[95px] lg:pb-[78px] ">
      <div class="grid lg:grid-cols-2 gap-y-14 place-items-center mobile-nav-child-even">
        <div class="flex flex-col gap-4 w-full lg:pr-0 lg:pl-10">
          <p class="h2 lg:pr-48">
            SARS CoV-2 Semi-Quantitative Antibody Testing
          </p>
          <p class="base pr-10">
            SARS-CoV-2 Semi-Quantitative Antibody Testing is a laboratory test that measures the levels of antibodies in
            a person's blood that were produced in response to the SARS-CoV-2 virus, the causative agent of COVID-19.
            This test is semi-quantitative, meaning it provides an estimate of the antibody levels rather than an exact
            measurement. It is used to determine if a person has been previously infected with the virus, even if they
            did not have symptoms, and to assess the level of immunity they may have developed.
          </p>
        </div>
        <img
            alt=""
            src="/imgs/covid/mask.png">
        <img
            class="order-4 lg:order-3"
            alt="" src="/imgs/covid/sample.png">
        <div class="flex flex-col gap-4 lg:pr-0  lg:pl-10 order-3 lg:order-4">
          <p class="h2 ">
            SARS-CoV-2 RT-PCR Testing
          </p>
          <p class="base">
            SARS-CoV-2 RT-PCR Testing is a highly sensitive and specific test used to detect the presence of the novel
            coronavirus causing COVID-19. It utilizes real-time RT-PCR technology to amplify and detect the virus'
            genetic material from a nasal or throat swab sample and is crucial in controlling the spread of the virus
            and providing an accurate diagnosis.
          </p>
        </div>
      </div>
  </div>
</template>

<script setup>
</script>