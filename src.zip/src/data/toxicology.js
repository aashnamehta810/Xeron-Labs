export const toxicology = [
  {
    name: "Cardiac Care",
    desc: "Supervised by board-certified cardiologists, the team is leading the way in innovative, successful care.",
    logo: "/imgs/toxicology/Cardiac-Care.svg",
    img: "/imgs/toxicology/Home-page-Cardiac-Care.jpg",
  },
  {
    name: "Dementia Care",
    desc: "Dementia by board-certified cardiologists, the team is leading the way in innovative, successful care.",
    logo: "/imgs/toxicology/Cardiac-Care.svg",
    img: "/imgs/toxicology/Home-page-Cardiac-Care.jpg",
  },
  {
    name: "Dialysis Care",
    desc: "Dialysis by board-certified cardiologists, the team is leading the way in innovative, successful care.",
    logo: "/imgs/toxicology/Cardiac-Care.svg",
    img: "/imgs/toxicology/Home-page-Cardiac-Care.jpg",
  },
];
