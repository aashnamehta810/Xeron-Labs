<template>
  <insurance-banner />
  <insurances-logo />
  <questions-banner />
  <qualities title="Discover the XCL Labs Difference" />
</template>

<script setup>
import InsuranceBanner from "@/Sections/InsurancesSections/InsuranceBanner.vue";
import InsurancesLogo from "@/Sections/InsurancesSections/InsurancesLogo.vue";
import QuestionsBanner from "@/Sections/SharedSections/QuestionsBanner.vue";
import Qualities from "@/Sections/SharedSections/Qualities.vue";
</script>

