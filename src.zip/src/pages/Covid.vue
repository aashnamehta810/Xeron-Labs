<template>
  <covid-banner/>
  <s-a-r-s-section />
  <get-tested />
  <benefits-section />
  <qualities title="Discover the XCL Labs Difference" />

</template>

<script setup>
import CovidBanner from "@/Sections/CovidSections/CovidBanner.vue";
import SARSSection from "@/Sections/CovidSections/SARSSection.vue";
import GetTested from "@/Sections/CovidSections/GetTested.vue";
import BenefitsSection from "@/Sections/CovidSections/BenefitsSection.vue";
import Qualities from "@/Sections/SharedSections/Qualities.vue";

</script>
