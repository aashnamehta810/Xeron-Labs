<template>
  <XeronLayout>
    <router-view />
  </XeronLayout>
</template>
<script setup>
import XeronLayout from "@/layouts/XeronLayout.vue";
</script>