<template>
    <div class="nav-width-parent-container">
        <div class="bg bg-center bg-cover bg-no-repeat text-white mobile-nav-child-uneven lg:px-[83px] pt-[44px]
         pb-[100px] rounded-[20px] text-center">
            <p class="tracking-[3.08px] text-[14px]">OUR SERVICES</p>
            <p class="font-naga h1 mt-[57px]">
                Trusted outcomes with a comprehensive range of laboratory services.
            </p>
        </div>
    </div>
</template>

<script setup>
</script>

<style scoped>
.bg {
    /* background-image: url("/imgs/about_banner.png"); */
    background-image: url("/imgs/service_banner_bg.png");
}
</style>
